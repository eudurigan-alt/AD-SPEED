package com.example.adspeed

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
        }
        layout.addView(TextView(this).apply {
            text = "AD SPEED\nPainel flutuante experimental"
            textSize = 23f
        })
        layout.addView(TextView(this).apply {
            text = "A velocidade escolhida ainda não altera anúncios de outros jogos. O painel serve para testar a janela flutuante."
            textSize = 16f
            setPadding(0, 24, 0, 24)
        })
        val permission = Button(this).apply {
            text = "Autorizar aparecer sobre outros apps"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivity(i)
                } else {
                    Toast.makeText(this@MainActivity, "Permissão já autorizada", Toast.LENGTH_SHORT).show()
                }
            }
        }
        layout.addView(permission)
        layout.addView(Button(this).apply {
            text = "Mostrar painel flutuante"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                    finish()
                } else {
                    Toast.makeText(this@MainActivity, "Autorize a permissão primeiro", Toast.LENGTH_LONG).show()
                }
            }
        })
        setContentView(layout)
    }
}
