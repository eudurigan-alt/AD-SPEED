package com.example.adspeed

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var panel: LinearLayout? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel != null) return START_STICKY
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 18, 24, 18)
            setBackgroundColor(0xEE20242B.toInt())
        }
        val title = TextView(this).apply {
            text = "AD SPEED  •  painel"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val speed = TextView(this).apply {
            text = "Velocidade selecionada: 1x"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val slider = SeekBar(this).apply {
            max = 9
            progress = 0
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    speed.text = "Velocidade selecionada: ${progress + 1}x"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        val close = TextView(this).apply {
            text = "FECHAR ✕"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 12, 0, 0)
            setOnClickListener { stopSelf() }
        }
        box.addView(title)
        box.addView(speed)
        box.addView(slider)
        box.addView(close)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 20
            y = 180
        }
        panel = box
        windowManager.addView(box, params)
        return START_STICKY
    }

    override fun onDestroy() {
        panel?.let { windowManager.removeView(it) }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
